import requests
from bs4 import BeautifulSoup
from lxml import etree
import json
import os


def translate_text(text, from_lang, to_lang):
    from googletrans import Translator
    translator = Translator()
    result = translator.translate(str(text), src=from_lang, dest=to_lang)
    return result.text


def generate_category_map(title, link, image=None):
    data = {
        "title_ru": title,
        "title_uz": translate_text(title, "ru", "uz"),
        "title_en": translate_text(title, "ru", "en"),
        "link": "https://letscolor.uz{}".format(link),
        "children": []
    }
    if image:
        data["image"] = image
        data["local_image"] = "/category/photos/{}".format(image.split("/")[-1])
    
    return data


def generate_category_map_in_ru(title, link):
    return {
        "title": title,
        "link": "https://letscolor.uz{}".format(link),
        "children": []
    }


def download(url, file_name):
    with open(file_name, "wb") as file:
        response = requests.get(url)
        file.write(response.content)


def send_category(category, parent=None):
    data = {
        "translations": json.dumps({
            "ru": {
                "name": category["title_ru"]
            },
            "en": {
                "name": category["title_en"]
            },
            "uz": {
                "name": category["title_uz"]
            }
        }),
        "slug": category["link"].split("/")[-1]
    }

    if parent:
        data["parent"] = parent
    
    files = {}
    if category.get("image", None):
        filename = category["image"].split("/")[-1]
        filepath = os.path.join(os.getcwd(), "category", "photos", filename)
        download(category["image"], filepath)
    
        files["icon"] = (filename, open(filepath, "rb"))

    result = requests.post("http://45.129.170.154/api/categories/", files=files, data=data)
    if result.status_code == 200 or result.status_code == 201:
        return result
    else:
        print(result.status_code)
        print(result.content)
        return send_category(category, parent)


def convert_to_float(dom_element):
    try:
        result = float(str(str(dom_element).split()[0]).replace(",", "."))
    except:
        result = 0.0
    return result


def get_product_page(title, link):
    print(title)
    res = requests.get(link)
    if res.status_code == 200:
        return res.content
    else:
        return get_product_page(title, link)


def get_product_detail(content):
    soup = BeautifulSoup(content, "html.parser")
    dom = etree.HTML(str(soup))
    product = {
        "title": dom.xpath("/html/body/div[5]/div[2]/div[1]/h1/text()"),
        "category_name": dom.xpath("/html/body/div[5]/div[2]/div[1]/h6/text()"),
        "price": convert_to_float(dom.xpath("/html/body/div[5]/div[2]/div[1]/div/h2/text()")),
        "description": dom.xpath("/html/body/div[5]/div[4]/div[1]/div[1]/p/text()")
    }


# URL = "https://letscolor.uz/store/ankery"

# res = requests.get(URL)

# if res.status_code == 200:
#     soup = BeautifulSoup(res.content, "html.parser")
#     dom = etree.HTML(str(soup))

#     i = 1
#     error_count = 0
#     _try = 3
#     while True:
#         link = dom.xpath(f"/html/body/div[5]/div[1]/div/div[3]/div[{i}]/div/div[2]/p/a/@href")
#         title = dom.xpath(f"/html/body/div[5]/div[1]/div/div[3]/div[{i}]/div/div[2]/p/a/text()")

#         if error_count < _try and (len(link) + len(title)) < 2:
#             error_count += 1
#         elif error_count == _try and (len(link) + len(title)) < 2:
#             break
#         else:
#             error_count = 0

#         print(link, title)

#         i += 1